package com.example.se2030.BoatSafariManagement.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "Customer")
@PrimaryKeyJoinColumn(name = "CustomerId")
@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class Customer extends User {

    public Customer(String email, String firstName, String lastName, String password) {
        super(email, firstName, lastName, password, "Customer");
    }
}