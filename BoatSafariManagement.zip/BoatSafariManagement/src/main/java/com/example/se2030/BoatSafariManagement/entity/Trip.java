package com.example.se2030.BoatSafariManagement.entity;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "Trip")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Trip {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "TripId")
    private Long tripId;

    @Column(name = "TripName")
    private String tripName;

    @Column(name = "Duration")
    private Integer duration;

    @Column(name = "DepartureTime", nullable = false)
    private LocalDateTime departureTime;

    @Column(name = "Destinations", columnDefinition = "NVARCHAR(MAX)")
    private String destinations;

    @Column(name = "Availability", nullable = false)
    private Integer availability;

    @Column(name = "Description", columnDefinition = "NVARCHAR(MAX)")
    private String description;

    @Column(name = "BasePrice", nullable = false, precision = 10, scale = 2)
    private BigDecimal basePrice;

    public Trip(String tripName, Integer duration, LocalDateTime departureTime,
                String destinations, Integer availability, String description, BigDecimal basePrice) {
        this.tripName = tripName;
        this.duration = duration;
        this.departureTime = departureTime;
        this.destinations = destinations;
        this.availability = availability;
        this.description = description;
        this.basePrice = basePrice;
    }
}