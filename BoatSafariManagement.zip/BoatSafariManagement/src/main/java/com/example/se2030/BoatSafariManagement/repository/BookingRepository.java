package com.example.se2030.BoatSafariManagement.repository;

import com.example.se2030.BoatSafariManagement.entity.Booking;
import com.example.se2030.BoatSafariManagement.entity.Customer;
import com.example.se2030.BoatSafariManagement.entity.Trip;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BookingRepository extends JpaRepository<Booking, Long> {
    List<Booking> findByCustomer(Customer customer);
    List<Booking> findByTrip(Trip trip);
    List<Booking> findByStatus(String status);
}