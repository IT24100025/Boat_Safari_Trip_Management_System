package com.example.se2030.BoatSafariManagement.controller;

import com.example.se2030.BoatSafariManagement.dto.BookingRequestDTO;
import com.example.se2030.BoatSafariManagement.dto.BookingResponseDTO;
import com.example.se2030.BoatSafariManagement.entity.*;
import com.example.se2030.BoatSafariManagement.service.BookingService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequiredArgsConstructor
public class BookingController {

    private final BookingService bookingService;

    // Serve the main HTML page
    @GetMapping("/")
    public String index() {
        return "index";
    }

    // Check trip availability
    @PostMapping("/api/check-availability")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> checkAvailability(
            @RequestParam String tripName,
            @RequestParam String date,
            @RequestParam String time,
            @RequestParam Integer guests,
            @RequestParam List<String> destinations) {

        Map<String, Object> response = new HashMap<>();

        try {
            LocalDate localDate = LocalDate.parse(date);
            LocalTime localTime = LocalTime.parse(time);

            Trip availableTrip = bookingService.findAvailableTrip(tripName, localDate, localTime, destinations);

            if (availableTrip != null) {
                response.put("available", true);
                response.put("trip", availableTrip);
                response.put("message", "Trip is available!");
                response.put("totalPrice", availableTrip.getBasePrice().multiply(BigDecimal.valueOf(guests)));
            } else {
                response.put("available", false);
                response.put("message", "No available trips found for the selected criteria.");
            }

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            response.put("available", false);
            response.put("message", "Error checking availability: " + e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }

    // Process booking
    @PostMapping("/api/book-trip")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> bookTrip(@RequestBody BookingRequestDTO bookingRequest) {
        Map<String, Object> response = new HashMap<>();

        try {
            // Find or create customer
            UserContact UserContact = null;
            Customer customer = bookingService.findOrCreateCustomer(
                    bookingRequest.getEmail(),
                    bookingRequest.getFirstName(),
                    bookingRequest.getLastName(),
                    bookingRequest.getContact(),
                    UserContact);

            // Find available trip
            Trip trip = bookingService.findAvailableTrip(
                    bookingRequest.getTripName(),
                    bookingRequest.getDate(),
                    bookingRequest.getTime(),
                    bookingRequest.getDestinations()
            );

            if (trip == null) {
                response.put("success", false);
                response.put("message", "Trip no longer available");
                return ResponseEntity.badRequest().body(response);
            }

            // Create booking
            String destinationsString = String.join(", ", bookingRequest.getDestinations());
            Booking booking = bookingService.createBooking(
                    customer,
                    trip,
                    bookingRequest.getGuests(),
                    bookingRequest.getSpecialRequests(),
                    destinationsString
            );

            // Process payment
            String cardLastFour = bookingRequest.getCardNo().length() > 4 ?
                    bookingRequest.getCardNo().substring(bookingRequest.getCardNo().length() - 4) :
                    bookingRequest.getCardNo();

            Payment payment = bookingService.processPayment(
                    booking,
                    bookingRequest.getPaymentMethod(),
                    cardLastFour
            );

            // Prepare response
            BookingResponseDTO bookingResponse = new BookingResponseDTO();
            bookingResponse.setBookingId("RS" + booking.getBookingId());
            bookingResponse.setCustomerName(bookingRequest.getFirstName() + " " + bookingRequest.getLastName());
            bookingResponse.setTripName(bookingRequest.getTripName());
            bookingResponse.setDate(bookingRequest.getDate().toString());
            bookingResponse.setTime(bookingRequest.getTime().toString());
            bookingResponse.setGuests(bookingRequest.getGuests());
            bookingResponse.setDestinations(destinationsString);
            bookingResponse.setTotalAmount(booking.getTotalPrice());
            bookingResponse.setPaymentTime(payment.getPaymentDate().format(
                    DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
            bookingResponse.setStatus("Confirmed");

            response.put("success", true);
            response.put("booking", bookingResponse);
            response.put("message", "Booking confirmed successfully!");

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Booking failed: " + e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }

    // Get all available trips
    @GetMapping("/api/trips")
    @ResponseBody
    public ResponseEntity<List<Trip>> getAllTrips() {
        List<Trip> trips = bookingService.getAllTrips();
        return ResponseEntity.ok(trips);
    }

    // Initialize sample data
    @PostMapping("/api/init-data")
    @ResponseBody
    public ResponseEntity<String> initializeSampleData() {
        try {
            bookingService.initializeSampleData();
            return ResponseEntity.ok("Sample data initialized successfully");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Error initializing data: " + e.getMessage());
        }
    }
}