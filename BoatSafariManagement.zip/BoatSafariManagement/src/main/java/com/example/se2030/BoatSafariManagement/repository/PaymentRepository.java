package com.example.se2030.BoatSafariManagement.repository;

import com.example.se2030.BoatSafariManagement.entity.Payment;
import com.example.se2030.BoatSafariManagement.entity.Booking;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface PaymentRepository extends JpaRepository<Payment, Long> {
    Optional<Payment> findByBooking(Booking booking);
}