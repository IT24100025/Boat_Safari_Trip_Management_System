package com.example.se2030.BoatSafariManagement.entity;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;

@Entity
@Table(name = "Booking")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Booking {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "BookingId")
    private Long bookingId;

    @ManyToOne
    @JoinColumn(name = "CustomerId", nullable = false)
    private Customer customer;

    @ManyToOne
    @JoinColumn(name = "TripId", nullable = false)
    private Trip trip;

    @Column(name = "BookingDate")
    private LocalDate bookingDate = LocalDate.now();

    @Column(name = "BookingTime")
    private LocalTime bookingTime = LocalTime.now();

    @Column(name = "NumOfGuests", nullable = false)
    private Integer numOfGuests;

    @Column(name = "TotalPrice", nullable = false, precision = 10, scale = 2)
    private BigDecimal totalPrice;

    @Column(name = "Status")
    private String status = "Pending";

    @Column(name = "SpecialRequests", columnDefinition = "NVARCHAR(MAX)")
    private String specialRequests;

    // Add these fields to match your database
    @Column(name = "AssignedStaffId")
    private Long assignedStaffId;

    @Column(name = "AssignedBoatId")
    private Long assignedBoatId;

    public Booking(Customer customer, Trip trip, Integer numOfGuests,
                   BigDecimal totalPrice, String specialRequests) {
        this.customer = customer;
        this.trip = trip;
        this.numOfGuests = numOfGuests;
        this.totalPrice = totalPrice;
        this.specialRequests = specialRequests;
    }

    public Booking(Customer customer, Trip trip, Integer numOfGuests, BigDecimal totalPrice, String specialRequests, String selectedDestinations) {
    }
}