package com.example.se2030.BoatSafariManagement.repository;

import com.example.se2030.BoatSafariManagement.entity.Trip;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface TripRepository extends JpaRepository<Trip, Long> {
    List<Trip> findByTripName(String tripName);

    @Query("SELECT t FROM Trip t WHERE t.departureTime >= :startDate AND t.departureTime <= :endDate")
    List<Trip> findTripsByDateRange(@Param("startDate") LocalDateTime startDate,
                                    @Param("endDate") LocalDateTime endDate);

    List<Trip> findByDepartureTimeAfter(LocalDateTime dateTime);
}