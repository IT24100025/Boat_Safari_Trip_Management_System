package com.example.se2030.BoatSafariManagement;

import com.example.se2030.BoatSafariManagement.service.BookingService;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@RequiredArgsConstructor
public class BoatSafariManagementApplication implements CommandLineRunner {

	private final BookingService bookingService;

	public static void main(String[] args) {
		SpringApplication.run(BoatSafariManagementApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		try {
			// Initialize sample data when application starts
			bookingService.initializeSampleData();
		} catch (Exception e) {
			System.out.println("Note: Sample data initialization skipped - " + e.getMessage());
		}

		// Display startup message
		displayStartupMessage();
	}

	private void displayStartupMessage() {
		System.out.println("\n\n");
		System.out.println("==================================================");
		System.out.println("BOAT SAFARI MANAGEMENT SYSTEM");
		System.out.println("==================================================");
		System.out.println("Application Started Successfully!");
		System.out.println("Open your browser and go to: http://localhost:8080");
		System.out.println("Database: Tables created automatically");
		System.out.println("Server: Running on port 8080");
		System.out.println("Sample trip data initialized");
		System.out.println("==================================================");
		System.out.println("\n");
	}
}