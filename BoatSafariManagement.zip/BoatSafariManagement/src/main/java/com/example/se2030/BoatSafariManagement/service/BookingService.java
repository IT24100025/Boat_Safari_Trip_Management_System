package com.example.se2030.BoatSafariManagement.service;

import com.example.se2030.BoatSafariManagement.entity.*;
import com.example.se2030.BoatSafariManagement.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
@RequiredArgsConstructor
public class BookingService {

    private final CustomerRepository customerRepository;
    private final TripRepository tripRepository;
    private final BookingRepository bookingRepository;
    private final PaymentRepository paymentRepository;
    private final UserRepository userRepository;

    public Customer findOrCreateCustomer(String email, String firstName, String lastName, String contact, UserContact UserContact) {
        Optional<Customer> existingCustomer = customerRepository.findByEmail(email);
        if (existingCustomer.isPresent()) {
            return existingCustomer.get();
        }

        // Create new customer
        Customer customer = new Customer(email, firstName, lastName, "defaultPassword");
        customer.getContactNumbers().add(UserContact);
        return customerRepository.save(customer);
    }

    public Trip findAvailableTrip(String tripName, java.time.LocalDate date, java.time.LocalTime time, List<String> destinations) {
        // Combine date and time to create LocalDateTime
        LocalDateTime departureDateTime = LocalDateTime.of(date, time);

        List<Trip> trips = tripRepository.findByTripName(tripName);

        return trips.stream()
                .filter(trip -> trip.getDepartureTime().isEqual(departureDateTime))
                .filter(trip -> hasMatchingDestinations(trip.getDestinations(), destinations))
                .filter(trip -> trip.getAvailability() > 0)
                .findFirst()
                .orElse(null);
    }

    private boolean hasMatchingDestinations(String tripDestinations, List<String> selectedDestinations) {
        if (tripDestinations == null || selectedDestinations == null) return false;

        String[] tripDests = tripDestinations.split(", ");
        for (String selected : selectedDestinations) {
            boolean found = false;
            for (String tripDest : tripDests) {
                if (tripDest.equalsIgnoreCase(selected)) {
                    found = true;
                    break;
                }
            }
            if (!found) return false;
        }
        return true;
    }

    public Booking createBooking(Customer customer, Trip trip, Integer numOfGuests,
                                 String specialRequests, String selectedDestinations) {
        BigDecimal totalPrice = trip.getBasePrice().multiply(BigDecimal.valueOf(numOfGuests));

        Booking booking = new Booking(customer, trip, numOfGuests, totalPrice,
                specialRequests, selectedDestinations);
        booking.setStatus("Confirmed");

        // Update trip availability
        trip.setAvailability(trip.getAvailability() - numOfGuests);
        tripRepository.save(trip);

        return bookingRepository.save(booking);
    }

    public Payment processPayment(Booking booking, String paymentMethod, String cardLastFour) {
        String transactionId = "TXN" + System.currentTimeMillis() + cardLastFour;

        Payment payment = new Payment(booking, booking.getTotalPrice(),
                paymentMethod, transactionId);

        return paymentRepository.save(payment);
    }

    public List<Trip> getAllTrips() {
        return tripRepository.findAll();
    }

    public void initializeSampleData() {
        try {
            // Small delay to ensure tables are created
            Thread.sleep(1000);

            // Add sample trips if none exist
            if (tripRepository.count() == 0) {
                System.out.println("Initializing sample trip data...");

                // Morning Safari trips
                tripRepository.save(new Trip("Morning Safari", 120,
                        LocalDateTime.of(2025, 10, 2, 6, 0),
                        "Madu River, Photography Spots", 20,
                        "Early morning wildlife spotting when animals are most active",
                        new BigDecimal("4800.00")));

                tripRepository.save(new Trip("Morning Safari", 120,
                        LocalDateTime.of(2025, 10, 3, 8, 0),
                        "Madu River, Cinnamon Island", 35,
                        "Classic morning safari with cultural experiences",
                        new BigDecimal("4500.00")));

                // Sunset Safari trips
                tripRepository.save(new Trip("Sunset Safari", 120,
                        LocalDateTime.of(2025, 10, 7, 17, 0),
                        "Bentota River, Sunset Views", 28,
                        "Early evening safari to catch the golden hour",
                        new BigDecimal("5200.00")));

                tripRepository.save(new Trip("Sunset Safari", 120,
                        LocalDateTime.of(2025, 10, 8, 17, 30),
                        "Bentota River, Sunset Views, Photography Spots", 40,
                        "Popular sunset timing with best photo opportunities",
                        new BigDecimal("5500.00")));

                System.out.println("✅ Sample trip data initialized successfully!");
            } else {
                System.out.println("ℹ️ Trip data already exists, skipping initialization.");
            }
        } catch (Exception e) {
            System.out.println("⚠️ Note: Could not initialize sample data - " + e.getMessage());
            // Don't throw the exception, just continue
        }
    }
}