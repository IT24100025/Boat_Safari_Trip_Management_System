package com.example.se2030.BoatSafariManagement.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "UserContact")
@Data
@NoArgsConstructor
@AllArgsConstructor
@IdClass(UserContactId.class)
public class UserContact {
    @Id
    @ManyToOne
    @JoinColumn(name = "UserId")
    private User user;

    @Id
    @Column(name = "ContactNo")
    private String contactNo;
}

// Composite key class
class UserContactId implements java.io.Serializable {
    private Long user;
    private String contactNo;

    // constructors, equals, hashCode
}