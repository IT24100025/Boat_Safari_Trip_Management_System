package com.example.se2030.BoatSafariManagement.entity;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "Payment")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Payment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "PaymentId")
    private Long paymentId;

    @OneToOne
    @JoinColumn(name = "BookingId", nullable = false)
    private Booking booking;

    @Column(name = "PaymentDate")
    private LocalDateTime paymentDate = LocalDateTime.now();

    @Column(name = "Amount", nullable = false, precision = 10, scale = 2)
    private BigDecimal amount;

    @Column(name = "Status")
    private String status = "Successful";

    @Column(name = "PaymentMethod", nullable = false)
    private String paymentMethod;

    @Column(name = "TransactionId")
    private String transactionId;

    public Payment(Booking booking, BigDecimal amount, String paymentMethod, String transactionId) {
        this.booking = booking;
        this.amount = amount;
        this.paymentMethod = paymentMethod;
        this.transactionId = transactionId;
    }
}